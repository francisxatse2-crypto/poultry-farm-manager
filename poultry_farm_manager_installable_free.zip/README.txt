POULTRY FARM MANAGER — V2.1 REAL FARM BUILD

Supabase project ref: mbuhamqfafcmpgddyari
URL: https://mbuhamqfafcmpgddyari.supabase.co

New in V2.1:
- Fixed mobile dashboard layout
- Horizontal navigation that remains usable on phones
- Dashboard KPIs now render clearly
- Feed stock inventory
- Medicine/vaccine records
- Supplier records
- Automatic report with mortality, production, feed, revenue, expenses and net cash
- Monthly cash-flow chart
- Print-ready report
- Delete records
- Cloud authentication and RLS

Database migration added:
add_inventory_and_suppliers

IMPORTANT:
This package is the app source. To publish it as a public/installable app, deploy index.html to a static host and use the Supabase publishable key for the project. Never expose a service-role key.
